# Y. P. Singh: portfolio, film platform and admin

Self-hosted website for Yogesh Pratap Singh (former IPS officer, author, film director, speaker): animated portfolio, film library, a player with a **free first 30 minutes and a one-time paywall for the rest**, Google + email sign-in, and an admin panel.

**Stack:** Node 22 (Express 4, built-in SQLite) · vanilla JS front end (no build step) · FFmpeg → HLS · Razorpay (or Cashfree) · nginx + Let's Encrypt on a Hostinger KVM VPS.

## Documentation
| Guide | |
|---|---|
| [docs/AUDIT.md](docs/AUDIT.md) | Findings from the code audit, severity, fixes, decisions |
| [docs/CHANGES.md](docs/CHANGES.md) | What changed, files, migrations, test results, known limits |
| [docs/GOOGLE_OAUTH.md](docs/GOOGLE_OAUTH.md) | Google Cloud setup, account-linking rules |
| [docs/PAYMENTS.md](docs/PAYMENTS.md) | Razorpay/Cashfree test and production setup, webhooks, refunds |
| [docs/VIDEO.md](docs/VIDEO.md) | Uploading a 10.8 GB film, FFmpeg/HLS, publishing, capacity |
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | VPS sizing, install, backups, restore, update, rollback |
| [docs/GO_LIVE.md](docs/GO_LIVE.md) | Launch checklist |

## Run locally
```bash
npm install
cp .env.example .env            # for local use set NODE_ENV=development and DATA_DIR=./data; leave payment keys empty for demo mode
npm run create-admin -- "Yogesh Singh" you@email.com 'a-long-strong-password'
npm run dev                     # http://localhost:3000   (needs ffmpeg + ffprobe on PATH)
```
Without payment keys (and outside production) checkout runs in clearly labelled **demo mode**. In production, missing keys disable checkout.

## Test
```bash
npm test          # 72 automated tests (needs ffmpeg), about 45 s, uses temp directories and fake gateways. No real charges
npm run check     # syntax check of every source file
```
There is no linter, type checker or build step in this project (plain JavaScript, no bundler). An optional browser smoke test is in `tests/e2e/smoke.cjs` (see the header of that file).

## Layout
```
server/            app.js (wiring, CSP), auth.js, google.js, config.js, db.js (versioned migrations)
server/payments/   ledger.js (all order/purchase state), razorpay.js, cashfree.js
server/routes/     auth, public, media (HLS gate), payments, admin, uploads (resumable)
server/transcode.js, hls.js, storage.js   ffmpeg jobs + validation, preview boundary, disk accounting
public/            site pages, js/, css/, admin/
deploy/            nginx, systemd, setup, backup, disk check
tests/             node:test suites
```
